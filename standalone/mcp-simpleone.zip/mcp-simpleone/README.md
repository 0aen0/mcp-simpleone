# SimpleOne MCP Server

MCP-сервер для интеграции с SimpleOne (ESM) через REST API. Позволяет ИИ-агентам выполнять CRUD-операции в ESM-системе.

## Быстрый старт

### 1. Настройка

1. Скопируйте `.env.example` в `.env`:
```bash
cp .env.example .env
```

2. Заполните конфигурацию:
```env
SIMPLEONE_URL=https://your-instance.simpleone.ru
SIMPLEONE_API_KEY=your-api-key-here
NODE_TLS_REJECT_UNAUTHORIZED=0    # Для самоподписанных сертификатов
```

Или используйте Basic Auth:
```env
SIMPLEONE_URL=https://your-instance.simpleone.ru
SIMPLEONE_BASIC_USER=your-username
SIMPLEONE_BASIC_PASSWORD=your-password
NODE_TLS_REJECT_UNAUTHORIZED=0    # Для самоподписанных сертификатов
```

## Запуск

**stdio транспорт (по умолчанию):**
```bash
npm start
```

**SSE транспорт:**
```bash
npm run start:sse
```

**HTTP транспорт:**
```bash
npm run start:http
```

## Сетевой доступ (SSE)

Для отладки и тестирования доступен HTTP/SSE транспорт:

**Endpoints:**
- `GET /sse` — SSE подключение
- `POST /message?sessionId=xxx` — отправка сообщений
- `GET /health` — проверка здоровья
- `GET /info` — информация о сервере и инструментах

**Порт:** 3000 (по умолчанию) или через `MCP_PORT` в .env

**Пример:**
```bash
# Запуск
npm run start:http

# Проверка
# Health check
curl http://localhost:3000/health

# Info (список инструментов)
curl http://localhost:3000/info

# SSE подключение (для отладки)
curl -N http://localhost:3000/sse
```

## Инструменты

| Tool | Описание | Подтверждение |
|---|---|---|
| `table_create` | Создание записи | ✅ Требуется |
| `table_read` | Чтение (ID или список) | ❌ Не требуется |
| `table_update` | Обновление записи | ✅ Требуется |
| `table_delete` | Удаление записи | ✅ Требуется |

## Параметры API

### table_read

| Параметр | Тип | Описание |
|---|---|---|
| `tableName` | string | Имя таблицы (обязательно) |
| `id` | string | ID записи (опционально) |
| `query` | string | Фильтр (например, `"active=1^priority=2"`) |
| `limit` | number | Макс. количество записей (по умолчанию 20) |
| `page` | number | Номер страницы (по умолчанию 1) |
| `no_count` | boolean | Отключить подсчёт записей (для оптимизации) |
| `display_value` | string | Возвращать отображаемые значения (`true/false/1/0`) |
| `exclude_reference_link` | boolean | Исключить ссылки для ссылочных полей |
| `fields` | string | Список полей через запятую (например, `"number,caller"`) |
| `view` | string | Представление формы для фильтрации полей |

### table_create

| Параметр | Тип | Описание |
|---|---|---|
| `tableName` | string | Имя таблицы (обязательно) |
| `data` | object | Данные для создания (обязательно) |
| `confirmed` | boolean | Флаг подтверждения |
| `display_value` | string | Возвращать отображаемые значения |
| `exclude_reference_link` | boolean | Исключить ссылки |
| `fields` | string | Список возвращаемых полей |
| `view` | string | Представление формы |

### table_update

| Параметр | Тип | Описание |
|---|---|---|
| `tableName` | string | Имя таблицы (обязательно) |
| `id` | string | ID записи (обязательно) |
| `data` | object | Данные для обновления (обязательно) |
| `confirmed` | boolean | Флаг подтверждения |
| `display_value` | string | Возвращать отображаемые значения |
| `exclude_reference_link` | boolean | Исключить ссылки |
| `fields` | string | Список возвращаемых полей |
| `view` | string | Представление формы |

## Примеры использования

### Чтение данных (без подтверждения)

**Базовый запрос:**
```
Вызови table_read с tableName="itsm_incident"
```

**С фильтрами и параметрами:**
```
Вызови table_read с tableName="itsm_incident", query="active=1^priority=1", limit=10, fields="number,description,state"
```

**Результат:** Список активных инцидентов с высоким приоритетом (макс. 10 записей).

**С отображаемыми значениями:**
```
Вызови table_read с tableName="task", id="177431367402911371", display_value="true"
```

**Результат:** Задача с отображаемыми значениями полей (например, имя пользователя вместо ID).

**С пагинацией и no_count:**
```
Вызови table_read с tableName="itsm_incident", query="active=1", limit=50, page=2, no_count=true
```

**Результат:** Вторая страница по 50 записей без подсчёта общего количества (оптимизация).

**С dot-walking (связанные поля):**
```
Вызови table_read с tableName="task", query="assigned_user.department=IT", fields="number,assigned_user.name,assigned_user.email"
```

**Результат:** Задачи с полями из связанной таблицы пользователя.

### Создание записи (с подтверждением)

**Базовый запрос:**
```
Вызови table_create с tableName="task", data={"subject": "Задача"}
```

**С параметрами:**
```
Вызови table_create с tableName="task", data={"subject": "Задача"}, fields="number,subject,sys_id"
```

**Результат:** Запрос подтверждения → после OK → задача создана с указанными полями в ответе.

### Обновление записи (с подтверждением)

**Базовый запрос:**
```
Вызови table_update с tableName="task", id="177431367402911371", data={"subject": "Новая тема"}
```

**С параметрами:**
```
Вызови table_update с tableName="task", id="177431367402911371", data={"state": "2"}, display_value="true", fields="number,state"
```

**Результат:** Запрос подтверждения → после OK → запись обновлена.

### Удаление записи (с подтверждением)

```
Вызови table_delete с tableName="task", id="177431367402911371"
```

**Результат:** Запрос подтверждения → после OK → запись удалена.


### API Endpoint

```
https://your-instance.simpleone.ru/rest/v1/table/{tableName}
https://your-instance.simpleone.ru/rest/v1/table/{tableName}/{sys_id}
```

### Поддерживаемые операторы query

| Оператор | Описание | Пример |
|---|---|---|
| `=` | Равно | `active=1` |
| `!=` | Не равно | `state!=closed` |
| `>`, `<`, `>=`, `<=` | Числовые сравнения | `priority>=2` |
| `LIKE` | Содержит | `subjectLIKEзадача` |
| `IN` | В списке | `priorityIN1,2,3` |
| `ISEMPTY` | Пустое | `assigned_userISEMPTY` |
| `ISNOTEMPTY` | Не пустое | `callerISNOTEMPTY` |
| `CHANGESTO` | Изменилось на | `stateCHANGESTO5` |
| `CHANGES` | Изменилось | `stateCHANGES` |
| `^` | И (AND) | `active=1^priority=2` |
| `^OR` | ИЛИ (OR) | `state=new^ORstate=in_progress` |
| `DYNAMIC` | Динамический фильтр | `assigned_toDYNAMIC156957117519820256` |

**Dot-walking:** Поддерживается в `query` и `fields` (например: `assigned_user.department=IT`)


## Примеры использования

### Создать инцидент
```
User: Создай инцидент с темой "Тестовая проблема"
Agent: [запросит подтверждение]
User: OK
Agent: INC0000001 создан
```

### Прочитать список
```
User: Покажи последние инциденты
Agent: [вызовет esm_read без ID]
```

### Обновить статус
```
User: Обнови статус INC0000001 на "В работе"
Agent: [запросит подтверждение]
User: OK
Agent: Статус обновлён
```

## Безопасность

- **Все write-операции требуют подтверждения** — создание, обновление, удаление
- **Секреты только в .env** — никогда не храните в коде
- **Маскировка в логах** — API-ключи и пароли не логируются


### Обновление автономной версии

```bash
# Замените каталог на сервере
rm -rf /opt/apps/mcp-simpleone
cp -r standalone/mcp-simpleone /opt/apps/mcp-simpleone

# Сохраните .env (не перезаписывайте!)
# Запустите сервер
cd /opt/apps/mcp-simpleone
npm start
```

## Ссылки

### Документация
- [MCP_SETUP.md](MCP_SETUP.md) — подробная инструкция по подключению MCP-клиентов
- [LOGGING.md](LOGGING.md) — настройка логирования
- [QUERY_EXAMPLES.md](QUERY_EXAMPLES.md) — примеры query-параметров

## Лицензия

MIT — см. [LICENSE](LICENSE) файл.
